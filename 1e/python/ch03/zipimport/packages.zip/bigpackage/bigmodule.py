# packages.zip is a ZIP archive that contains the bigpackage directory
# and this source file (bigmodule.py).  It's included here under the
# UNUSED_packages directory so you can see what's in it.  The app
# itself doesn't use the UNUSED_packages, and imports this module
# directly from the ZIP archive.

def print_message():
    print '<p>You have called the print_message() function.</p>'
